let v = document.getElementById("i1").value;


  if (v === "") {
    document.getElementById("ans").innerText = "";
  } else {

    if(v == "a" || v == "A")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(v == "e" || v == "E")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(v == "i" || v == "I")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(v == "o" || v == "O")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(v == "u" || v == "U")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else
    {

        document.getElementById("ans").innerText = "It's Not Vowel"

    }

  }