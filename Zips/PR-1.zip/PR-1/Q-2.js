let l = document.getElementById("i1").value
let w = document.getElementById("i2").value

let a = l*w
document.getElementById("ans").innerText = 'Area Of Rectangle Is ' + a