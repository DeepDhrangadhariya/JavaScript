let a1 = 5
let a2 = 3

let a3 = a1+a2

document.getElementById("a1").innerText = 'Addition Of 5 + 3 Is ' + a3

let s1 = 10
let s2 = 4

let s3 = s1-s2

document.getElementById("a2").innerText = 'Subtraction Of 10 - 4 Is ' + s3

let m1 = 7
let m2 = 6

let m3 = m1*m2

document.getElementById("a3").innerText = 'Multiplication Of 7 * 6 Is ' + m3

let d1 = 20
let d2 = 5

let d3 = d1/d2

document.getElementById("a4").innerText = 'Division Of 20 / 5 Is ' + d3

let o1 = 8
let o2 = 2

let o3 = o1%o2

document.getElementById("a5").innerText = 'Modulus Of 8 % 2 Is ' + o3