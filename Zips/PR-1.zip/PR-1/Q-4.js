let p = document.getElementById("i1").value
let r = document.getElementById("i2").value
let t = document.getElementById("i3").value

let a = (p * r * t) / 100
document.getElementById("ans").innerText = 'Simple Interest Is ' + a