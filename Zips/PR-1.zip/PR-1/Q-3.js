let f = document.getElementById("i1").value

let a = (f - 32) * 5/9

document.getElementById("ans").innerText = 'Fahrenheit to Celsius Is ' + a