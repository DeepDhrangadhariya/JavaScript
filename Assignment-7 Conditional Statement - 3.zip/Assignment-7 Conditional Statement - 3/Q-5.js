let c = document.getElementById("i1").value;


  if (c === "") {
    document.getElementById("ans").innerText = "";
  } else {

    if(c == "a" || c == "A")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(c == "e" || c == "E")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(c == "i" || c == "I")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(c == "o" || c == "O")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else if(c == "u" || c == "U")
    {

        document.getElementById("ans").innerText = "It's Vowel"

    }
    else
    {

        document.getElementById("ans").innerText = "It's Consonant"

    }

  }