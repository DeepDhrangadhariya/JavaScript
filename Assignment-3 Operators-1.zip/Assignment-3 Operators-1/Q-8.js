let a = 10

document.getElementById("normal").innerText = "Normal Value of a Is : a = " + a

a += 90

document.getElementById("added").innerText = "90 Added In Value of a Is : a = " + a