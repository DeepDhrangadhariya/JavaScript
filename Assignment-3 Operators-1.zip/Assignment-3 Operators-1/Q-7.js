let a = 69

document.getElementById("old").innerText = "a Is : " + a

a++

document.getElementById("new").innerText = "a Is Incremented By 1 Is : " + a