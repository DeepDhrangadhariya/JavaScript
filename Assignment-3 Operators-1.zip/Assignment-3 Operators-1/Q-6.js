let a = 50

let b = 60

let c = 70

let d = 80

document.getElementById("one").innerText = "a = " + a

document.getElementById("two").innerText = "b = " + b

document.getElementById("three").innerText = "c = " + c

document.getElementById("four").innerText = "d = " + d

document.getElementById("final").innerText = "Result Is : " + a > b || c < d