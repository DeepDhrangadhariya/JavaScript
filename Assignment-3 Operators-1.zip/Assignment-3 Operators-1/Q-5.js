var a = 10

var b = 20

var c = 30

var d = 40

document.getElementById("first").innerText = "a = " + a

document.getElementById("second").innerText = "b = " + b

document.getElementById("third").innerText = "c = " + c

document.getElementById("forth").innerText = "d = " + d

document.getElementById("result").innerText = "Result Is : " + a < b && c > d