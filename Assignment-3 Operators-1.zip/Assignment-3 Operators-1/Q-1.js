let a = 10
let b = 20

document.getElementById("first").innerText = "a = " + a

document.getElementById("second").innerText = "b = " + b

let s = a + b

document.getElementById("sum").innerText = a + " + " + b + " = " + s