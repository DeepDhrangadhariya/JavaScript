var a = 20

var b = 5

document.getElementById("one").innerText = "a = " + a

document.getElementById("two").innerText = "b = " + b

document.getElementById("multiply").innerText = a + " * " + b + " = " + a*b